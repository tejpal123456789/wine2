from core.logger import Logger
print('musku')
l=Logger('teju')
print(l)
l.info('syx')