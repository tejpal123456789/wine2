import os
from core.config import config_data
from core.logger import Logger
from src.get_data import getdata
print('dfgh')
