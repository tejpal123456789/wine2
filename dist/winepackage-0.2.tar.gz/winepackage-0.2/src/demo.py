from core.logger import Logger
print('musku')
l=Logger('teju')
l.info('syx')