import os
import yaml

from core.logger import Logger
print('yeju')
class config_data:
    def __init__(self,name,config_path):
        self.config_path=config_path
        self.name=name
        self.logger=Logger(name)

  
    def read_params(self,config_path):
      try:
        self.logger.info('start reading params file')
        with open(config_path) as yaml_file:
           config=yaml.safe_load(yaml_file)
        print(config)   
        return config

      except Exception:
        self.logger.exception('Having error in reading params.yaml file')
        raise Exception
    

c=config_data('config','params.yaml')

c.read_params('params.yaml')