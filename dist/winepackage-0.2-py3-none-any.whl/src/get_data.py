import os
from re import L
import yaml
import pandas as pd
import argparse
#print('teju')
import logging
from core.logger import Logger
from core.config import config_data
print('teju')
class getdata:
  def __init__(self,logger_name):
    self.logger_name=logger_name
    self.logger=Logger(self.logger_name) 

  def read_params(self,config_path):
    try:
        self.self.logger.info('start reading params file')
        with open(config_path) as yaml_file:
           config=yaml.safe_load(yaml_file)
        return config

    except Exception:
        self.logger.exception('Having error in reading params.yaml file')
        raise Exception


  def get_data(self,config_path):
    try:
        self.logger.info('getting data from the data source')
        config=self.read_params(config_path)
    #print(config)
    
        data_path=config['data_source']['s3_source']

        df=pd.read_csv(data_path,sep=',',encoding='utf-8')
        print(df.head())
        self.logger.info('Data has been got sucuusfully')
        return df
    except Exception:
        self.logger.exception('something has happen wrong while getting data from data source')
        raise Exception


