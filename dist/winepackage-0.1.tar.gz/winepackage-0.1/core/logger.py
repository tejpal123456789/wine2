import logging

class Logger:
    def __init__(self,logger_name):
        self.logger_name=logger_name

    def get_logger(self,logger_name):
        logger=logging.getLogger(self.logger_name)
        return logger

    def info(self,message):
        self.logger.info(message)

    def exception(self,message):
        self.logger.exception(message)        