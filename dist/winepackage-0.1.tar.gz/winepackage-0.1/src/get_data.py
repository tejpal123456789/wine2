import os
from re import L
import yaml
import pandas as pd
import argparse
#print('teju')
import logging
from core.logger import Logger
print('teju')
class getdata:
  def read_params(config_path,logger):
    try:
        logger.info('start reading params file')
        with open(config_path) as yaml_file:
           config=yaml.safe_load(yaml_file)
        return config

    except Exception:
        logger.exception('Having error in reading params.yaml file')
        raise Exception


  def get_data(config_path,logger):
    try:
        logger.info('getting data from the data source')
        config=read_params(config_path)
    #print(config)
    
        data_path=config['data_source']['s3_source']

        df=pd.read_csv(data_path,sep=',',encoding='utf-8')
        print(df.head())
        logger.info('Data has been got sucuusfully')
        return df
    except Exception:
        logger.exception('something has happen wrong while getting data from data source')
        raise Exception


